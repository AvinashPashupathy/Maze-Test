﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MazeExplorer;

namespace MazeUnitTest
{
    [TestClass]
    public class SvcUnitTest
    {
        private readonly MazeSvc _service = new MazeSvc();
        private readonly Maze _maze = new Maze();

        /// <summary>
        /// Test CreateMaze method with valid input for service
        /// </summary>
        [TestMethod]
        public void TestCreateMaze_Valid()
        {
            var mazeArray = _service.CreateMaze("Example_2.txt");
            Assert.AreEqual('X', mazeArray[0, 0]);
        }

        /// <summary>
        /// Test CreateMaze method with invalid input for service
        /// </summary>
        [TestMethod]
        public void TestCreateMaze_Invalid()
        {
            var mazeArray = _service.CreateMaze("Example_yu.txt");
            Assert.AreEqual(mazeArray, null);
        }

        /// <summary>
        /// Test CreateMaze method with null input
        /// </summary>
        [TestMethod]
        public void TestCreateMaze_Null()
        {
            var mazeArray = _service.CreateMaze("~@#~@#");
            Assert.AreEqual(mazeArray, null);
        }

        /// <summary>
        /// Test FindValue Method for valid input
        /// </summary>
        [TestMethod]
        public void TestFindValue_Valid()
        {
            var mazeArray = _service.CreateMaze("Example_2.txt");
            char mazeChar = _service.FindValue(mazeArray, 2, 18);
            Assert.AreEqual('S', mazeChar);
        }

        /// <summary>
        /// Test FindValue Method for invalid input
        /// </summary>
        [TestMethod]
        public void TestFindValue_Invalid()
        {
            char mazeChar = _service.FindValue(null, 1, 1);
            Assert.AreEqual('~', mazeChar);
        }

        [TestMethod]
        public void TestFindPath_ValidStart()
        {
            bool isSolved = false;
            var mazeArray = _service.CreateMaze("Example_2.txt");
            isSolved = _service.FindPath(1, 1);
            Assert.AreEqual(isSolved, false);
        }

        [TestMethod]
        public void TestFindPath_InvalidStart()
        {
            bool isSolved = false;
            char[,] mazeArray = _service.CreateMaze("Example_2.txt"); ;
            isSolved = _service.FindPath(-1, -1);
            Assert.AreEqual(isSolved, false);
        }

        [TestMethod]
        public void TestFindPath_InvalidPath()
        {
            bool isSolved = false;
            char[,] mazeArray = _service.CreateMaze("Example_NoSolution.txt");
            isSolved = _service.FindPath(1, 1);
            Assert.AreEqual(isSolved, false);
        }

        [TestMethod]
        public void TestFindIndex_Start()
        {
            var mazeArray = _service.CreateMaze("Example_2.txt");
            int[] index = _service.FindIndex(mazeArray, 'S');
            Assert.AreEqual(2, index[0]);
            Assert.AreEqual(18, index[1]);
        }

        [TestMethod]
        public void TestFindIndex_Finish()
        {
            var mazeArray = _service.CreateMaze("Example_2.txt");
            int[] index = _service.FindIndex(mazeArray, 'F');
            Assert.AreEqual(15, index[0]);
            Assert.AreEqual(8, index[1]);
        }


    }
}
