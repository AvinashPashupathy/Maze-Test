﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MazeExplorer;

namespace MazeUnitTest
{
    [TestClass]
    public class ClassUnitTest
    {
        private readonly MazeSvc _service = new MazeSvc();
        private readonly Maze _maze = new Maze();

        /// <summary>
        /// Test CreateMaze method with valid input for client
        /// </summary>
        [TestMethod]
        public void Test_DisplayMaze_Valid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_1.txt");
            mazeObj.DisplayMaze();
        }

        /// <summary>
        /// Test CreateMaze method with invalid input for client
        /// </summary>
        [TestMethod]
        public void Test_DisplayMaze_Invalid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_1rt.txt");
            mazeObj.DisplayMaze();
        }

        /// <summary>
        /// Test FindValue for Start Point
        /// </summary>
        [TestMethod]
        public void Test_FindValue_Start()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            Assert.AreEqual("Start", mazeObj.FindValue(2,18));
        }

        /// <summary>
        /// Test FindValue for Finish Point
        /// </summary>
        [TestMethod]
        public void Test_FindValue_Finish()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            Assert.AreEqual("Finish", mazeObj.FindValue(15,8));
        }

        /// <summary>
        /// Test FindValue for Wall Point
        /// </summary>
        [TestMethod]
        public void Test_FindValue_Wall()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            Assert.AreEqual("Wall", mazeObj.FindValue(0, 0));
        }

        /// <summary>
        /// Test FindValue for Space Point
        /// </summary>
        [TestMethod]
        public void Test_FindValue_Space()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            Assert.AreEqual("Space", mazeObj.FindValue(0, 15));
        }

        /// <summary>
        /// Test FindValue for Invalid Point
        /// </summary>
        [TestMethod]
        public void Test_FindValue_Invalid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            Assert.AreEqual("The entered co-ordinates is out of range of the maze.", mazeObj.FindValue(50, 50));
        }

        [TestMethod]
        public void Test_FindPath_Valid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            mazeObj.FindPath();
        }

        [TestMethod]
        public void Test_FindCoordinates_Valid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            mazeObj.FindCoordinates("1, 2");
        }

        [TestMethod]
        public void Test_FindCoordinates_InValid()
        {
            MazeClass mazeObj = new MazeClass(new MazeSvc(), "Example_2.txt");
            mazeObj.FindCoordinates("1r, t");
        }

    }
}
