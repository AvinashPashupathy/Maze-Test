﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeExplorer
{
    public class MazeClass
    {
        #region [Private Members]
        private readonly IMazeSvc _maze;
        public char[,] _mazeArray;
        #endregion

        /// <summary>
        /// Initialize service object and assigns File path
        /// </summary>
        /// <param name="maze"></param>
        /// <param name="filePath"></param>
        public MazeClass(IMazeSvc maze, string filePath)
        {
            this._maze = maze;
            _mazeArray = _maze.CreateMaze(filePath);
        }

        /// <summary>
        /// Displays Maze
        /// </summary>
        public void DisplayMaze()
        {
            _maze.DisplayMaze(_mazeArray);
        }

        /// <summary>
        /// Finds value for the required coordinate
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="colIndex"></param>
        /// <returns></returns>
        public string FindValue(int rowIndex, int colIndex)
        {
            char mazeChar = _maze.FindValue(_mazeArray, rowIndex, colIndex);
            mazeChar = char.IsWhiteSpace(mazeChar) ? '_' : mazeChar;
            string result = string.Empty;
            switch (mazeChar)
            {
                case 'S':
                    result = "Start";
                    break;
                case 'F':
                    result = "Finish";
                    break;
                case 'X':
                    result = "Wall";
                    break;
                case '_':
                    result = "Space";
                    break;
                case '~':
                    result = "The entered co-ordinates is out of range of the maze.";
                    break;
            }

            return result;
        }

        public void FindPath()
        {
            //Call SolveMaze method for input Maze array
            _maze.solveMaze(ref _mazeArray);
            //if maze is solved, display the solved maze
            //else display the original problem with an appropriate message saying 
            //no possible path is found for the given problem
            _maze.DisplayMaze(_mazeArray);
        }

        public void FindCoordinates(string line)
        {
            int ptX = -1, ptY = -1;
            var index = line != null ? line.Split(',') : new string[1];
            if (index.Length == 2)
            {
                //Check if coordinates are entered in expected format
                if (int.TryParse(index[0], out ptX) && int.TryParse(index[1], out ptY) && ptX != -1 && ptY != -1)
                {
                    Console.WriteLine(FindValue(Convert.ToInt32(index[0]), Convert.ToInt32(index[1])));
                }
                else
                {
                    Console.Write("Incorrect co-ordinates. Please try again.");
                }
            }
            else
            {
                Console.Write("Incorrect co-ordinates. Please try again.");
            }
        }

        //public bool CanMove(int rowIndex, int colIndex)
        //{
        //    string cellValue = FindValue(rowIndex, colIndex);
        //    return (cellValue == "Space" || cellValue == "Finish" || cellValue == "Start");
        //}
    }
}
