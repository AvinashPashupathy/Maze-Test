﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MazeExplorer
{
    public class MazeSvc : IMazeSvc
    {

        #region [Variables]
        public char[,] mazeArray;
        int rowLength, colLength;
        int startX, startY; // Starting X and Y values of maze
        int finishX, finishY;     // Ending X and Y values of maze
        bool[,] vistedArray;
        bool[,] correctArray; // The solution to the maze
        double[,] distanceArray; //Distance of Finish Point from a point
        bool[,] revisitedArray;
        bool[,] shortestArray;
        #endregion

        public char[,] CreateMaze(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    String input = File.ReadAllText(filePath);
                    string[] rows = input.Split('\n');
                    int colLength = rows[0].Length;
                    int rowIndex = 0, colIndex = 0;
                    //Find maximum column size
                    foreach (var row in rows)
                    {
                        colLength = colLength > row.Length ? colLength : row.Length;
                    }
                    mazeArray = new char[rows.Count(), colLength];
                    //read character by character from each line
                    foreach (var row in rows)
                    {
                        colIndex = 0;
                        foreach (var col in row.TrimEnd().ToCharArray())
                        {
                            mazeArray[rowIndex, colIndex] = col;
                            colIndex++;
                        }
                        rowIndex++;
                    }
                }
                else
                {
                    Console.WriteLine("Input Maze file is not found in the specified path. Please try again.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in creating Maze: " + ex.Message);
            }
            return mazeArray;
        }

        /// <summary>
        /// Displays the Maze
        /// </summary>
        /// <param name="mazeArray">Input Char Array of Maze</param>
        public void DisplayMaze(char[,] mazeArray)
        {
            try
            {
                rowLength = mazeArray.GetLength(0);
                colLength = mazeArray.GetLength(1);
                //Display the content of char array character by character
                for (int rowIndex = 0; rowIndex < rowLength; rowIndex++)
                {
                    for (int colIndex = 0; colIndex < colLength; colIndex++)
                    {
                        Console.Write(mazeArray[rowIndex, colIndex]);
                    }
                    Console.Write(Environment.NewLine);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in displaying Maze: " + ex.Message);
            }
        }

        public char FindValue(char[,] mazeArray, int rowIndex, int colIndex)
        {
            char result;
            try
            {
                rowLength = mazeArray.GetLength(0);
                colLength = mazeArray.GetLength(1);
                //if the coordinates are with in the range of maze, find the value
                if (rowIndex > -1 && colIndex > -1 && rowIndex < rowLength && colIndex < colLength)
                {
                    result = mazeArray[rowIndex, colIndex];
                }
                else
                {
                    result = '~';
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured: " + ex.Message);
                result = '~';
            }
            return result;
        }

        public int[] FindIndex(char[,] mazeArray, char charValue)
        {
            int[] index = new int[2];
            int rowLength, colLength;
            try
            {
                rowLength = mazeArray.GetLength(0);
                colLength = mazeArray.GetLength(1);
                index[0] = -1;
                index[1] = -1;
                for (int rowIndex = 0; rowIndex < rowLength; rowIndex++)
                {
                    for (int colIndex = 0; colIndex < colLength; colIndex++)
                    {
                        if (mazeArray[rowIndex, colIndex].Equals(charValue))
                        {
                            index[0] = rowIndex;
                            index[1] = colIndex;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in finding index: " + ex.Message);
            }
            return index;
        }

        public void solveMaze(ref char[,] maze)
        {
            bool result = false;
            try
            {
                mazeArray = maze;
                rowLength = mazeArray.GetLength(0);
                colLength = mazeArray.GetLength(1);

                //get Start point indexes
                startX = FindIndex(mazeArray, 'S')[0];
                startY = FindIndex(mazeArray, 'S')[1];
                //get Finish Point indexes
                finishX = FindIndex(mazeArray, 'F')[0];
                finishY = FindIndex(mazeArray, 'F')[1];


                //create arrays for holding flags for visited and correct and sel all values to false
                vistedArray = new bool[rowLength, colLength];
                correctArray = new bool[rowLength, colLength];
                distanceArray = new double[rowLength, colLength];
                revisitedArray = new bool[rowLength, colLength];
                shortestArray = new bool[rowLength, colLength];
                for (int rowIndex = 0; rowIndex < rowLength; rowIndex++)
                {
                    for (int colIndex = 0; colIndex < colLength; colIndex++)
                    {
                        vistedArray[rowIndex, colIndex] = false;
                        correctArray[rowIndex, colIndex] = false;
                        revisitedArray[rowIndex, colIndex] = false;
                        shortestArray[rowIndex, colIndex] = false;
                        distanceArray[rowIndex, colIndex] = FindDistance(rowIndex, colIndex);
                    }
                }

                //Call FindPath with Start point indexes
                result = FindPath(startX, startY);

                //Set '+' value to the 'correct' indexes
                if (result)
                {
                    for (int rowIndex = 0; rowIndex < rowLength; rowIndex++)
                    {
                        for (int colIndex = 0; colIndex < colLength; colIndex++)
                        {
                            if (correctArray[rowIndex, colIndex] && mazeArray[rowIndex, colIndex] != 'F')
                            {
                                mazeArray[rowIndex, colIndex] = '+';
                            }
                        }
                    }
                    FindShortest(startX, startY);

                    for (int rowIndex = 0; rowIndex < rowLength; rowIndex++)
                    {
                        for (int colIndex = 0; colIndex < colLength; colIndex++)
                        {
                            if (mazeArray[rowIndex, colIndex] == '+' || mazeArray[rowIndex, colIndex] == '-')
                            {
                                mazeArray[rowIndex, colIndex] = ' ';
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No possible path is found. Please check the input maze.");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in solving the maze: " + ex.Message);
            }
        }

        public bool FindPath(int ptX, int ptY)
        {
            try
            {
                if (mazeArray != null)
                {
                    int rowLength = mazeArray.GetLength(0);
                    int colLength = mazeArray.GetLength(1);
                    //check if the indexes are same as that of Finish point
                    if (finishX == ptX && finishY == ptY)
                    {
                        return true;
                    }

                    if (ptX >= 0 && ptY >= 0 && ptX < rowLength && ptY < colLength)
                    {
                        //check if the point is wall or already visited
                        if (mazeArray[ptX, ptY] == 'X' || vistedArray[ptX, ptY])
                        {
                            return false;
                        }

                        vistedArray[ptX, ptY] = true;

                        //Find the adjacent points and call the function recursively with new point

                        //left point
                        if (ptX - 1 >= 0 && FindPath(ptX - 1, ptY))
                        {
                            correctArray[ptX - 1, ptY] = true;
                            return true;
                        }
                        //right point
                        if (ptX + 1 < rowLength && FindPath(ptX + 1, ptY))
                        {
                            correctArray[ptX + 1, ptY] = true;
                            return true;
                        }

                        //top point
                        if (ptY - 1 >= 0 && FindPath(ptX, ptY - 1))
                        {
                            correctArray[ptX, ptY - 1] = true;
                            return true;
                        }

                        //bottom point 
                        if (ptY + 1 < colLength && FindPath(ptX, ptY + 1))
                        {
                            correctArray[ptX, ptY + 1] = true;
                            return true;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Input Maze is not loaded. Please check if the file exists in the specified path.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in solving the maze: " + ex.Message);
            }
            return false;
        }

        public void FindShortest(int ptX, int ptY)
        {
            try
            {

                if (ptX >= 0 && ptY >= 0 && ptX < rowLength && ptY < colLength)
                {
                    //check if the point is wall or already visited
                    if ((mazeArray[ptX, ptY] == '+' || mazeArray[ptX, ptY] == '-' || mazeArray[ptX, ptY] == 'S' || mazeArray[ptX, ptY] == 'F') && !revisitedArray[ptX, ptY])
                    {
                        revisitedArray[ptX, ptY] = true;
                        double distanceFound = 0;
                        int shortX = -1, shortY = -1;
                        //Find the adjacent points and call the function recursively with new point

                        if (ptX - 1 >= 0 && mazeArray[ptX - 1, ptY] == '+')
                        {
                            distanceFound = distanceArray[ptX - 1, ptY];
                            mazeArray[ptX - 1, ptY] = '-';
                            shortX = ptX - 1;
                            shortY = ptY;
                        }

                        if (ptX + 1 < rowLength && mazeArray[ptX + 1, ptY] == '+' && (distanceFound > distanceArray[ptX + 1, ptY] || distanceFound == 0))
                        {
                            distanceFound = distanceArray[ptX + 1, ptY];
                            mazeArray[ptX + 1, ptY] = '-';
                            shortX = ptX + 1;
                            shortY = ptY;
                        }


                        if (ptY - 1 >= 0 && mazeArray[ptX, ptY - 1] == '+' && (distanceFound > distanceArray[ptX, ptY - 1] || distanceFound == 0))
                        {
                            distanceFound = distanceArray[ptX, ptY - 1];
                            mazeArray[ptX, ptY - 1] = '-';
                            shortX = ptX;
                            shortY = ptY - 1;
                        }


                        if (ptY + 1 < colLength && mazeArray[ptX, ptY + 1] == '+' && (distanceFound > distanceArray[ptX, ptY + 1] || distanceFound == 0))
                        {
                            distanceFound = distanceArray[ptX, ptY + 1];
                            mazeArray[ptX, ptY + 1] = '-';
                            shortX = ptX;
                            shortY = ptY + 1;
                            //CheckIfShortest(ptX, ptY + 1);
                        }

                        if (shortX >= 0 && shortY >= 0)
                        {
                            FindShortest(shortX, shortY);
                            mazeArray[shortX, shortY] = '.';
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in finding the shortest path: " + ex.Message);
            }
        }

        public double FindDistance(int ptX, int ptY)
        {
            double distance = 0;
            int finishX = 0, finishY = 0;
            finishX = FindIndex(mazeArray, 'F')[0];
            finishY = FindIndex(mazeArray, 'F')[1];

            distance = Math.Sqrt(Math.Pow((finishX - ptX), 2) + Math.Pow((finishY - ptY), 2));
            return distance;
        }


    }

}
