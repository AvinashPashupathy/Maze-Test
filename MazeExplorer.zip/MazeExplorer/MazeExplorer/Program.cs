﻿using System;
using System.Configuration;
using System.Diagnostics;

namespace MazeExplorer
{
    public class Maze
    {
        //static int startX, startY;
        static MazeClass MazeObj;
        //static int srow, scol;
        static void Main(string[] args)
        {
            int userChoice = 0;

            try
            {
                string filePath = ConfigurationManager.AppSettings["FilePath"];

                while (true)
                {
                    //create layout screen
                    Console.WriteLine("***********************");
                    Console.WriteLine("     Maze Explorer     ");
                    Console.WriteLine("***********************");
                    Console.WriteLine("Maze File: " + filePath);
                    Console.WriteLine(Environment.NewLine);

                    Console.WriteLine("1. Display & Explore Maze");
                    Console.WriteLine("2. Check Co-Ordinate");
                    Console.WriteLine("3. Exit");

                    Console.WriteLine(Environment.NewLine);
                    Console.WriteLine("Please enter your choice:");

                    int.TryParse(Console.ReadLine(), out userChoice);
                    if (userChoice >= 1 && userChoice <= 3)
                    {
                        MazeObj = new MazeClass(new MazeSvc(), filePath);
                        switch (userChoice)
                        {
                            case 1:
                                //ExploreMaze();
                                MazeObj.FindPath();
                                break;
                            case 2:
                                Console.Write("Please enter (x,y) co-ordinates (without braces, e.g. 7,8):");
                                var line = Console.ReadLine();
                                MazeObj.FindCoordinates(line);
                                break;
                            case 3:
                                Environment.Exit(0);
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("sorry! No action found for entered key. Please try again");
                        Console.WriteLine(Environment.NewLine);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message + ". Please try again");
            }
        }

        ///Commented 
        // Approach 2: Traversing the user using Navigation keys
        //public static void ExploreMaze()
        //{
        //    Console.Clear();
        //    MazeObj.DisplayMaze();

        //    //Start point indexes
        //    startX = MazeObj.FindIndex(client._mazeArray, 'S')[0];
        //    startY = MazeObj.FindIndex(client._mazeArray, 'S')[1];
        //    srow = startX;
        //    scol = startY;

        //    Console.SetCursorPosition(scol, srow);
        //    Console.Write("S");
        //    Console.SetCursorPosition(scol, srow);

        //    while (true)
        //    {
        //        ConsoleKeyInfo info = Console.ReadKey(true);
        //        if (info.Key == ConsoleKey.UpArrow && MazeObj.CanMove(srow - 1, scol))
        //        {
        //            Console.Write(".");
        //            srow--;
        //        }

        //        else if (info.Key == ConsoleKey.DownArrow && MazeObj.CanMove(srow + 1, scol))
        //        {
        //            Console.Write(".");
        //            srow++;
        //        }

        //        else if (info.Key == ConsoleKey.LeftArrow && MazeObj.CanMove(srow, scol - 1))
        //        {
        //            Console.Write(".");
        //            scol--;
        //        }

        //        else if (info.Key == ConsoleKey.RightArrow && MazeObj.CanMove(srow, scol + 1))
        //        {
        //            Console.Write(".");
        //            scol++;
        //        }

        //        Console.SetCursorPosition(scol, srow);
        //        if (MazeObj.FindValue(srow, scol) == "Finish")
        //        {
        //            break;
        //        }
        //        Console.Write("*");
        //        Console.SetCursorPosition(scol, srow);

        //    }
        //    Console.Clear();
        //    Console.WriteLine("Congrats!! You have solved the Maze");
        //    Console.WriteLine();
        //}



    }

}


