﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeExplorer
{
    class Strategy2 : IMazeSvc
    {
        public char[,] mazeArray;
        public char[,] CreateMaze(string filePath)
        {
            return mazeArray;
        }

        public void DisplayMaze(char[,] mazeArray)
        {

        }

        public char FindValue(char[,] mazeArray, int rowIndex, int colIndex)
        {
            return 'S';
        }

        public void solveMaze(ref char[,] maze)
        {

        }


    }
}
