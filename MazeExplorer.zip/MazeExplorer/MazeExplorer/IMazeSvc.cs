﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeExplorer
{
    public interface IMazeSvc
    {
        char[,] CreateMaze(string filePath);

        void DisplayMaze(char[,] mazeArray);

        char FindValue(char[,] mazeArray, int rowIndex, int colIndex);

        void solveMaze(ref char[,] maze);

    }
}
